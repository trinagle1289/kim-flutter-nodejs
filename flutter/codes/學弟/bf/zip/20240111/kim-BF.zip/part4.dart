import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟四',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 40),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                '施力評級',
                style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('施力等級',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '低',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '低',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '中等',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '中等',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '高',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '高',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '極高',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '極高',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '達到峰值',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '達到峰值',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('頻率',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '握持時間[秒]:_',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '握持時間[秒]:_',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '移動頻率[次數]:_',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '移動頻率[次數]:_',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('性別',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '男',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '男',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '女',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '女',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
