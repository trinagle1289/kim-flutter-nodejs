import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Button App',
      initialRoute: '/',
      routes: {
        '/': (context) => const ThirdPage(),
        '/next': (context) => const NextPage(),
      },
    );
  }
}

class ThirdPage extends StatefulWidget {
  const ThirdPage({Key? key}) : super(key: key);

  @override
  _ThirdPageState createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  int selectedOption = -1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text(
          '不良工作條件-背部',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 30, color: Colors.black),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 30),
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 20.0, right: 10.0),
                child: Text('每天從事此作業時間佔比',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    )),
              ),
            ),
            Column(
              children: [
                buildCircularCheckbox(0, 1, ['<25%', '25-49%']),
                buildCircularCheckbox(2, 3, ['51-75%', '>75%']),
              ],
            ),
            const SizedBox(height: 20),
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 20.0, right: 10.0),
                child: Text('軀幹扭轉/測傾',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    )),
              ),
            ),
            Column(
              children: [
                buildCircularCheckbox(4, 4, ['偶爾']),
                buildCircularCheckbox(5, 5, ['經常']),
              ],
            ),
            const SizedBox(height: 20),
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 20.0, right: 10.0),
                child: Text('頭部後傾/嚴重地前傾/維持轉頭姿勢',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    )),
              ),
            ),
            Column(
              children: [
                buildCircularCheckbox(6, 6, ['偶爾或經常']),
                buildCircularCheckbox(7, 7, ['軀幹前傾時沒有支撐']),
                buildCircularCheckbox(8, 8, ['經常處在狹窄空間']),
                buildCircularCheckbox(9, 9, ['不穩定、不平整地板']),
                buildCircularCheckbox(10,10, ['潮濕、冷、極乾、衣服淋濕']),
                buildCircularCheckbox(11,11, ['強烈震動']),
                buildCircularCheckbox(12,12, ['需極度心理專注']),
              ],
            ),

            const SizedBox(height: 80),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text(
                    '上一步',
                    style: TextStyle(fontSize: 30, color: Colors.white),
                  ),
                ),
                const SizedBox(width: 13),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/next');
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text(
                    '下一步',
                    style: TextStyle(fontSize: 30, color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget buildCircularCheckbox(int start, int end, List<String> titles) {
    List<Widget> checkboxes = [];

    for (int i = start; i <= end; i++) {
      checkboxes.add(
        ListTile(
          title: Text(
            titles[i - start],
            style: const TextStyle(fontSize: 20, color: Colors.black),
          ),
          leading: Radio(
            value: i,
            groupValue: selectedOption,
            onChanged: (value) {
              setState(() {
                selectedOption = value as int;
              });
            },
            activeColor: Colors.blue,
          ),
        ),
      );
    }

    return Column(
      children: checkboxes,
    );
  }
}

class NextPage extends StatelessWidget {
  const NextPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Next Page'),
      ),
      body: const Center(
        child: Text('This is the next page.'),
      ),
    );
  }
}