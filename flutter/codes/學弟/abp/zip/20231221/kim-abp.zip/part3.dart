import 'package:flutter/material.dart';

void main() => runApp(const Step3App());

class Step3App extends StatelessWidget {
  const Step3App({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: Step3Field());
  }
}

class Step3Field extends StatelessWidget {
  const Step3Field({super.key});
  @override
  Widget build(BuildContext context) {
    var appTitle = const Align(
        alignment: Alignment.center,
        child:
        Text('步驟三', style: TextStyle(fontSize: 40, color: Colors.white)));

    var times1 = const Text('時間評級',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold));
    var times3 = const Text('                           ',
        style: TextStyle(fontSize: 20));
    var times2 = const Text('每天從事此作業時間',
        style: TextStyle(fontSize: 30, color: Colors.black));

    var appBody = Stack(
      children: [
        Column(
          children: [
            Expanded(
              child: Align(
                alignment: Alignment.center,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      times3,
                      times1,
                      times3,
                      times2,
                      times3,
                      Container(
                        decoration: BoxDecoration(
                            border:
                            Border.all(color: Colors.black, width: 1.2)),
                        child: DropdownButton<String>(
                            hint:
                            const Text(' 大約為', textAlign: TextAlign.center),
                            onChanged: (String? newValue) {
                            },
                            style: const TextStyle(
                                fontSize: 25, color: Colors.black),
                            items: <String>[
                              '1小時',
                              '2小時',
                              '3小時',
                              '4小時',
                              '5小時',
                              '6小時',
                              '7小時',
                              '8小時',
                              '9小時',
                              '10小時',
                            ].map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                  value: value, child: Text(value));
                            }).toList()),
                      ),
                    ]),
              ),
            ),
          ],
        ),

        // 下一步按鈕
        Positioned(
          bottom: 30,
          right: 20,
          child: ElevatedButton(
              onPressed: () {

                // Navigator.push(context,
                //     MaterialPageRoute(builder: (context) => getLhcApp("4")));
              },
              style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0))),
                  backgroundColor:
                  MaterialStateProperty.all<Color>(Colors.blue),
                  minimumSize:
                  MaterialStateProperty.all<Size>(const Size(170, 50))),
              child: const Text('下一步', style: TextStyle(fontSize: 30))),
        ),

        // 上一步按鈕
        Positioned(
          bottom: 30,
          left: 20,
          child: ElevatedButton(
            onPressed: (){
            },
            style: ButtonStyle(
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0))),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                minimumSize:
                MaterialStateProperty.all<Size>(const Size(170, 50))),
            child: const Text('上一步', style: TextStyle(fontSize: 30)),
          ),
        ),
      ],
    );

    return Scaffold(
        appBar: AppBar(backgroundColor: Colors.blue, title: appTitle),
        body: appBody);
  }
}
