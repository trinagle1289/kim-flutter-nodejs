import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟七',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 40),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                '身體姿勢',
                style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('姿勢評級:3',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '身體直立或輕微前傾、無扭轉',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '身體直立或輕微前傾、無扭轉',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '施力的高度可自由選擇',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '施力的高度可自由選擇',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '腳部無障礙物',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '腳部無障礙物',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('姿勢評級:5',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '身體傾向移動方向、測面拉動重物時需稍微扭轉身體',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '身體傾向移動方向、測面拉動重物時需稍微扭轉身體',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '施力的高度固定在0.9-1.2公尺',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '施力的高度固定在0.9-1.2公尺',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),

              ListTile(
                title: const Text(
                  '腳部少量障礙物',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '腳部少量障礙物',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '幾乎都在做「拉」的動作',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '幾乎都在做「拉」的動作',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('姿勢評級:8',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '不協調的身體姿勢\n- 施力的高度固定在<0.9或>1.2公尺\n- 單邊的側向施力\n- 視野嚴重受阻',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '不協調的身體姿勢\n- 施力的高度固定在<0.9或>1.2公尺\n- 單邊的側向施力\n- 視野嚴重受阻',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '腳部明顯障礙物',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '腳部明顯障礙物',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '身體經常扭轉/測傾',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '身體經常扭轉/測傾',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
