import 'package:flutter/material.dart';

void main() => runApp(const Part3_7());

class Part3_7 extends StatelessWidget {
  const Part3_7({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟三',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 40),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                '搬運重量(含搬運工具)',
                style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 15),
              ListTile(
                title: const Text(
                  '≤ 50 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '≤ 50 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '51 ~100 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '51 ~100 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '101~200 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '101~200 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '201~300 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '201~300 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '301~400 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '301~400 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '401~600 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '401~600 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '601~800 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '601~800 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '801~1000 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '801~1000 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '1001~1300 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '1001~1300 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '> 1300 (kg)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '> 1300 (kg)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 15),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
