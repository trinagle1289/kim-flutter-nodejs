import 'package:flutter/material.dart';

void main() => runApp(const Part5());

class Part5 extends StatelessWidget {
  const Part5({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟五',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 42),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                '工作條件',
                style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),

              ListTile(
                title: const Text(
                  '需經常停下，搬運工具有煞車',
                  style: TextStyle(
                    fontSize: 22,
                  ),
                ),
                leading: Radio<String>(
                  value: '需經常停下，搬運工具有煞車',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                title: const Text(
                  '需經常停下，搬運工具無煞車',
                  style: TextStyle(
                    fontSize: 22,
                  ),
                ),
                leading: Radio<String>(
                  value: '需經常停下，搬運工具無煞車',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                title: const Text(
                  '搬抬工具陷入地面或卡住，\n經常需要大量啟動施力',
                  style: TextStyle(
                    fontSize: 22,
                  ),
                ),
                leading: Radio<String>(
                  value: '由搬抬工具陷入地面或卡住，\n經常需要大量啟動施力',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                title: const Text(
                  '需常轉換方向、彎曲路線',
                  style: TextStyle(
                    fontSize: 22,
                  ),
                ),
                leading: Radio<String>(
                  value: '需常轉換方向、彎曲路線',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                title: const Text(
                  '重物需放置非常精確、\n路徑需走的非常精確',
                  style: TextStyle(
                    fontSize: 22,
                  ),
                ),
                leading: Radio<String>(
                  value: '重物需放置非常精確、\n路徑需走的非常精確',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                title: const Text(
                  '移動速度增加\n(約 1 - 1.3 公尺/秒)',
                  style: TextStyle(
                    fontSize: 22,
                  ),
                ),
                leading: Radio<String>(
                  value: '移動速度增加\n(約 1 - 1.3 公尺/秒)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
