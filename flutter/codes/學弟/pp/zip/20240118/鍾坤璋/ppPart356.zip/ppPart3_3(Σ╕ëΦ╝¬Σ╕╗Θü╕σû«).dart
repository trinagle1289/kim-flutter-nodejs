import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Page1(selectedIndex: -1),
  ));
}
class Page1 extends StatelessWidget {
  final List<String> image = [
    'assets/4.png',
    'assets/6.png',
    'assets/10.png',
  ];

  final List<String> imageDescriptions = [
    '可轉動輪',
    '定向輪子\n可鎖定的可轉動輪',
    '行人控制型',
  ];

  final int selectedIndex;

  Page1({required this.selectedIndex});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('步驟三',
            style:TextStyle(fontSize: 40),
          ),
        ),
      ),
      body: Column(
        children: [
          const SizedBox(height: 30),
          const Text(
            '≥ 三輪推車',
            style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 35),
          Expanded(
            child: GridView.builder(
              itemCount: image.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                  },
                  child: Container(
                    margin: EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      border: selectedIndex == index ? Border.all(color: Colors.blue, width: 3) : null,
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.asset(image[index]),
                        ),
                        Text(
                          imageDescriptions[index],
                          style: TextStyle(
                            fontSize: 20.0,
                          ),
                        ), // 圖片下的文字描述
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 5, 25),
                  child: ElevatedButton(
                    onPressed: null, // 按鈕禁用
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                    ),
                    child: const Text(
                      '上一步',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 3),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(5, 0, 10, 25),
                  child: ElevatedButton(
                    onPressed: null, // 按鈕禁用
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                    ),
                    child: const Text(
                      '下一步',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
