import 'package:flutter/material.dart';

void main() => runApp(const Step3of2App());

class Step3of2App extends StatelessWidget {
  const Step3of2App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text('步驟三', textAlign: TextAlign.center, style: TextStyle(fontSize: 40)),
        ),
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 20),
                const Text(
                  '搬運工具',
                  style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                const Text(
                  '頭上的輸送帶/起重機',
                  style: TextStyle(fontSize: 30),
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('301~400'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('401~600'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('601~800'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('801~1000'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('1001~1300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('> 1300'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(right: 30),
                            child: Image.asset(
                              'picture/頭上的輸送帶.png',
                              width: 150,
                              height: 150,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('301~400'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('401~600'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('601~800'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('801~1000'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('> 1000'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: Image.asset(
                              'picture/頭上的起重機.png',
                              width: 150,
                              height: 150,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ElevatedButton(
                onPressed: () {},
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {},
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

