import 'package:flutter/material.dart';

void main() => runApp(const Step3App());

class Step3App extends StatelessWidget {
  const Step3App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text('步驟三', textAlign: TextAlign.center, style: TextStyle(fontSize: 40)),
        ),
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 20),
                const Text(
                  '搬運工具',
                  style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold),
                ),
                const Padding(
                  padding:  EdgeInsets.only(left: 15), // 调整左边距
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child:  Text(
                      '請選擇搬運的工具，',
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                ),
                const Padding(
                  padding:  EdgeInsets.only(left: 15), // 调整左边距
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child:  Text(
                      '並點選搬運之重量[公斤]',
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('>301'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(right: 23),
                            child: Image.asset(
                              'picture/二輪推車1.png',
                              width: 102,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('301~400'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('>401'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: Image.asset(
                              'picture/二輪推車2.png',
                              width: 90,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('>301'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: Image.asset(
                              'picture/二輪推車3.png',
                              width: 102,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('301~400'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('401~600'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('601~800'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('>800'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(right: 30),
                            child: Image.asset(
                              'picture/三輪推車1.png',
                              width: 102,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('301~400'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('401~600'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('>600'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(right: 30),
                            child: Image.asset(
                              'picture/三輪推車2.png',
                              width: 100,
                              height: 110,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        PopupMenuButton(
                          onSelected: (value) {
                            // 處理選中的菜單項目
                            print('選擇了: $value');
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              child: Text('≤ 50'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('51 ~100'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('101~200'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('201~300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('301~400'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('401~600'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('601~800'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('801~1000'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('1001~1300'),
                              value: '',
                            ),
                            const PopupMenuItem(
                              child: Text('> 1300'),
                              value: '',
                            ),
                          ],
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 20, right: 10),
                            child: Image.asset(
                              'picture/三輪推車3.png',
                              width: 102,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    PopupMenuButton(
                      onSelected: (value) {
                        // 處理選中的菜單項目
                        print('選擇了: $value');
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          child: Text('≤ 50'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('51 ~100'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('101~200'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('201~300'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('301~400'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('401~600'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('601~800'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('801~1000'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('1001~1300'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('> 1300'),
                          value: '',
                        ),
                      ],
                      child: Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: Image.asset(
                          'picture/三輪推車5.png',
                          width: 200,
                          height: 100,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    PopupMenuButton(
                      onSelected: (value) {
                        // 處理選中的菜單項目
                        print('選擇了: $value');
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          child: Text('≤ 50'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('51 ~100'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('101~200'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('201~300'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('301~400'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('401~600'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('601~800'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('801~1000'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('1001~1300'),
                          value: '',
                        ),
                        const PopupMenuItem(
                          child: Text('> 1300'),
                          value: '',
                        ),
                      ],
                      child: Padding(
                        padding: const EdgeInsets.only(right: 30),
                        child: Image.asset(
                          'picture/三輪推車6.png',
                          width: 160,
                          height: 90,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ],
                ),

              ],
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ElevatedButton(
                onPressed: () {},
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {},
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

