import 'package:flutter/material.dart';

void main() => runApp(const Step3App());

class Step3App extends StatelessWidget {
  const Step3App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟六',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 40),
          ),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const SizedBox(height: 30),
            const Text(
              '工作條件',
              style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ListTile(
              title: const Text(
                '良好',
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
              subtitle: const Text(
                '無不良的工作條件，例如：安全要素易辨識 / 無眩光 / 良好氣候環境',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              leading: Radio<String>(
                value: '良好',
                groupValue: null,
                onChanged: (_) {}, // 空函數，不進行任何操作
              ),
            ),
            ListTile(
              title: const Text(
                '受限',
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
              subtitle: const Text(
                '偶爾因眩光或過小作業而妨礙作業辨識 / 強風、寒冷、潮濕、噪音等不良環境',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              leading: Radio<String>(
                value: '受限',
                groupValue: null,
                onChanged: (_) {}, // 空函數，不進行任何操作
              ),
            ),
            ListTile(
              title: const Text(
                '不良',
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
              subtitle: const Text(
                '頻繁地因眩光或過小作業而妨礙作業辨識 / 強風、寒冷、潮濕、噪音等不良環境',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              leading: Radio<String>(
                value: '不良',
                groupValue: null,
                onChanged: (_) {}, // 空函數，不進行任何操作
              ),
            ),
          ],
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
