import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟三(1/2)',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 40),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                '手-手指部位的施力評級(左手)',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              ListTile(
                title: const Text(
                  '力量低 (至多15%最大施力)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                subtitle: const Text(
                  '平均握持時間 [秒/分]: _\n平均移動次數 [次數/分]: _',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
                leading: Radio<String>(
                  value: '力量低 (至多15%最大施力)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '力量中等 (至多30%最大施力)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                subtitle: const Text(
                  '平均握持時間 [秒/分]: _\n平均移動次數 [次數/分]: _',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
                leading: Radio<String>(
                  value: '力量中等 (至多30%最大施力)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '力量高 (至多50%最大施力)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                subtitle: const Text(
                  '平均握持時間 [秒/分]: _\n平均移動次數 [次數/分]: _',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
                leading: Radio<String>(
                  value: '力量高 (至多50%最大施力)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '力量極高 (至多80%最大施力)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                subtitle: const Text(
                  '平均握持時間 [秒/分]: _\n平均移動次數 [次數/分]: _',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
                leading: Radio<String>(
                  value: '力量極高 (至多80%最大施力)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '力量達到峰值 (超過80%最大施力)',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                subtitle: const Text(
                  '平均握持時間 [秒/分]: _\n平均移動次數 [次數/分]: _',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
                leading: Radio<String>(
                  value: '力量達到峰值 (超過80%最大施力)',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '用力捶打',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                subtitle: const Text(
                  '平均握持時間 [秒/分]: _\n平均移動次數 [次數/分]: _',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
                leading: Radio<String>(
                  value: '用力捶打',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
