import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Button App',
      initialRoute: '/',
      routes: {
        '/': (context) => const ThirdPage(),
        '/next': (context) => const NextPage(),
      },
    );
  }
}

class ThirdPage extends StatelessWidget {
  const ThirdPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text(
          '步驟四(2/2)',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 42, color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 30),
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 25.0, right: 10.0),
                child: Text(
                  '身體活動: 人力交通工具',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 70.0, right: 10.0),
                child: Text(
                  '路況不良工作條件',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            CheckboxListTile(
              title: const Text(
                '路況受限',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
              value: false, // Replace with your boolean variable
              onChanged: (newValue) {
                // Update your state here
              },
              controlAffinity: ListTileControlAffinity.leading,
              activeColor: Colors.blue,
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                '泥土、粗糙砂石、坑洞、黏重土壤、短暫上升坡道',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            const SizedBox(height: 20),
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 20.0, right: 10.0),
                child: Text(
                  '氣候條件',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 20.0, right: 10.0),
                child: Text(
                  '氣候劇烈變化 (e.g 熱、風、雪)',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Column(
              children: [
                buildCircularCheckbox(0, 1, ['稀少、偶爾', '經常、頻繁']),
              ],
            ),
            const SizedBox(height: 165),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {

                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text(
                    '上一步',
                    style: TextStyle(fontSize: 30, color: Colors.white),
                  ),
                ),
                const SizedBox(width: 13),
                ElevatedButton(
                  onPressed: () {

                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text(
                    '下一步',
                    style: TextStyle(fontSize: 30, color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget buildCircularCheckbox(int start, int end, List<String> titles) {
    List<Widget> checkboxes = [];

    for (int i = start; i <= end; i++) {
      checkboxes.add(
        ListTile(
          title: Text(
            titles[i - start],
            style: const TextStyle(fontSize: 20, color: Colors.black),
          ),
          leading: Radio(
            value: i,
            groupValue: null, // Replace with your group value
            onChanged: (value) {
              // Update your state here
            },
            activeColor: Colors.blue,
          ),
        ),
      );
    }

    return Column(
      children: checkboxes,
    );
  }
}

class NextPage extends StatelessWidget {
  const NextPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Next Page'),
      ),
      body: const Center(
        child: Text('This is the next page.'),
      ),
    );
  }
}
