import 'package:flutter/material.dart';

void main() => runApp(const Step2App());

class Step2App extends StatelessWidget {
  const Step2App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: const Center(
              child:
              Text('步驟二', style: TextStyle(fontSize: 40, color: Colors.white,))),
        ),
        body: Stack(
          children: [
            Center(
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  const Text(
                    '時間評級',
                    style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    '每天執行時間[分鐘/天]',
                    style: TextStyle(fontSize: 30, color: Colors.black),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 1.2),
                    ),
                    child: DropdownButton<String>(
                      hint: const Text(' 大約為', textAlign: TextAlign.center),
                      onChanged: (String? newValue) {},
                      style: const TextStyle(fontSize: 25, color: Colors.black),
                      items: <String>[
                        '≦1',
                        '>1-5',
                        '>5-10',
                        '>10-20',
                        '>20-30',
                        '>30-45',
                        '>45-60',
                        '>60-100',
                        '>100-150',
                        '>150-210',
                        '>210-270',
                        '>270-360',
                        '>360-480',
                      ].map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),

            // 下一步按鈕
            Positioned(
              bottom: 30,
              right: 20,
              child: ElevatedButton(
                onPressed: () {},
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('下一步', style: TextStyle(fontSize: 30)),
              ),
            ),

            // 上一步按鈕
            Positioned(
              bottom: 30,
              left: 20,
              child: ElevatedButton(
                onPressed: () {},
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('上一步', style: TextStyle(fontSize: 30)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
