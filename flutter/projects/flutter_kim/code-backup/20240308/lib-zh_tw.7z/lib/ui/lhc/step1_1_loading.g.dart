// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'step1_1_loading.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$loadingTextHash() => r'88ff050c83e8fcc295b3ed248c1cf91d836eb06a';

/// 加載文字
///
/// Copied from [_LoadingText].
@ProviderFor(_LoadingText)
final _loadingTextProvider =
    AutoDisposeNotifierProvider<_LoadingText, String>.internal(
  _LoadingText.new,
  name: r'_loadingTextProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$loadingTextHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LoadingText = AutoDisposeNotifier<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
