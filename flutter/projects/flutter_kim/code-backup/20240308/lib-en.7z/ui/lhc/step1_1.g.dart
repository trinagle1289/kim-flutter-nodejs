// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'step1_1.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$recordBtnColorHash() => r'352ec09e55899ee3d86544441f0df5a498f1953d';

/// 錄影按鈕顏色
///
/// Copied from [_RecordBtnColor].
@ProviderFor(_RecordBtnColor)
final _recordBtnColorProvider =
    AutoDisposeNotifierProvider<_RecordBtnColor, Color>.internal(
  _RecordBtnColor.new,
  name: r'_recordBtnColorProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$recordBtnColorHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RecordBtnColor = AutoDisposeNotifier<Color>;
String _$recordBtnTextHash() => r'b369f3912b1c9ee8b5593e25734f7025aee85fce';

/// 錄影按鈕文字
///
/// Copied from [_RecordBtnText].
@ProviderFor(_RecordBtnText)
final _recordBtnTextProvider =
    AutoDisposeNotifierProvider<_RecordBtnText, String>.internal(
  _RecordBtnText.new,
  name: r'_recordBtnTextProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$recordBtnTextHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RecordBtnText = AutoDisposeNotifier<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
