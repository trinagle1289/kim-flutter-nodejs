import 'package:flutter/material.dart';
import 'dart:js';

void main() => runApp(TestPage());

class TestPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}

class TestModel {
  String model_path = "";
}

class TestViewModel {}
