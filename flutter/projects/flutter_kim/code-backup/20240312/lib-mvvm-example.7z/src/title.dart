// Packages
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// Pages
import 'package:flutter_kim_workspace/main.dart';

// Main Function
void main() => runApp(const KIMApp());

/// 開頭 KIM 量表選擇介面
class TitlePage extends StatelessWidget {
  const TitlePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Key Indicator Method (KIM)'),
          backgroundColor: Theme.of(context).primaryColor),
      body: ListView.builder(
          padding: const EdgeInsets.all(16.0), // Padding
          itemCount: TitleViewModel.getScaleNumber, // Number of Items
          scrollDirection: Axis.vertical, // Vertical Scroll
          // Items
          itemBuilder: (context, idx) {
            // 按鈕是否放置左側
            bool isLeft = idx % 2 == 0;
            // 對齊方式
            var alignType =
                isLeft ? Alignment.centerLeft : Alignment.centerRight;

            return Column(
              children: [
                Align(
                  alignment: alignType,
                  child: chooseBtn(
                      text: TitleViewModel.getSubScaleName(idx),
                      isLeft: isLeft,
                      onPressedFn: () =>
                          context.go(TitleViewModel.getSubScaleRoute(idx))),
                ),
                const SizedBox(height: 20)
              ],
            );
          }),
    );
  }

  /// 選擇按鈕元件
  Widget chooseBtn(
      {required String text, required bool isLeft, Function()? onPressedFn}) {
    // 設定按鈕顏色
    Color btnColor = isLeft
        ? const Color.fromRGBO(245, 200, 200, 1.0) // 左邊按鈕顏色
        : const Color.fromRGBO(189, 225, 225, 1.0); // 右邊按鈕顏色

    return ElevatedButton(
      // 按鈕格式
      style: ElevatedButton.styleFrom(
          backgroundColor: btnColor,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 20)),
      // 按鈕行為
      onPressed: () => onPressedFn!(),
      // 文字格式
      child: SizedBox(
        width: 200, // 寬度
        child: Center(child: Text(text, style: const TextStyle(fontSize: 20))),
      ),
    );
  }
}

/// 標題模型
class TitleModel {
  /// 子量表名稱
  static var subScaleName = [
    "人工物料搬運\n(KIM-LHC)",
    "手動處理操作\n(KIM-MHO)",
    "推拉作業搬運\n(KIM-PP)",
    "不當姿勢作業\n(KIM-ABP)",
    "Whole-body Forces\n(KIM-BF)",
    "Body Movement\n(KIM-BM)",
    "測試區域",
    "測試區域2"
  ];

  /// 子量表路徑
  static var routes = [
    "/lhc",
    "/mho",
    "/pp",
    "/abp",
    "/bf",
    "/bm",
    "/test",
    "/test2",
  ];
}

/// 標題檢視模型
class TitleViewModel {
  /// 取得子量表數量
  static int getScaleNumber = TitleModel.subScaleName.length;

  /// 取得子量表名稱
  static String getSubScaleName(int idx) => TitleModel.subScaleName[idx];

  /// 取得子量表路徑
  static String getSubScaleRoute(int idx) => TitleModel.routes[idx];
}
