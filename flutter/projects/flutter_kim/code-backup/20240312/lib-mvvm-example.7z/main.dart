// Flutter Packages
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// Pages
import 'package:flutter_kim_workspace/src/title.dart';
import 'package:flutter_kim_workspace/src/test/test.dart';

// Main Function
void main() => runApp(const KIMApp());

/// 介面路徑
final _router = GoRouter(routes: [
  GoRoute(
    name: "標題頁面",
    path: "/",
    builder: (context, state) => const TitlePage(),
  ),
  GoRoute(
    name: "測試頁面",
    path: "/test",
    builder: (context, state) => TestPage(),
  )
]);

/// KIM 應用程式
class KIMApp extends StatelessWidget {
  const KIMApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: "KIM 介面",
      theme: ThemeData(
        primaryColor: const Color.fromRGBO(245, 147, 147, 1),
        buttonTheme: ButtonThemeData(
          textTheme: ButtonTextTheme.primary,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        ),
      ),
      routerConfig: _router,
    );
  }
}
