// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'step1_2.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$poseturePtsHash() => r'08efbb76740945b158a4d6b69571680f882b969e';

/// 姿勢評級分數
///
/// Copied from [_PoseturePts].
@ProviderFor(_PoseturePts)
final _poseturePtsProvider =
    AutoDisposeNotifierProvider<_PoseturePts, int>.internal(
  _PoseturePts.new,
  name: r'_poseturePtsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$poseturePtsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PoseturePts = AutoDisposeNotifier<int>;
String _$startPoseImgPathHash() => r'784e51a097879578cc11ed11f664b81d616eb372';

/// 開始姿勢圖片路徑
///
/// Copied from [_StartPoseImgPath].
@ProviderFor(_StartPoseImgPath)
final _startPoseImgPathProvider =
    AutoDisposeNotifierProvider<_StartPoseImgPath, String>.internal(
  _StartPoseImgPath.new,
  name: r'_startPoseImgPathProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$startPoseImgPathHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$StartPoseImgPath = AutoDisposeNotifier<String>;
String _$endPoseImgPathHash() => r'e267bbfdf6e0bde38599d540d7d7fa984ef4124f';

/// 結束姿勢圖片路徑
///
/// Copied from [_EndPoseImgPath].
@ProviderFor(_EndPoseImgPath)
final _endPoseImgPathProvider =
    AutoDisposeNotifierProvider<_EndPoseImgPath, String>.internal(
  _EndPoseImgPath.new,
  name: r'_endPoseImgPathProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$endPoseImgPathHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EndPoseImgPath = AutoDisposeNotifier<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
