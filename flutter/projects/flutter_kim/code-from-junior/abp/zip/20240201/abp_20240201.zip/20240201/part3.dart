import 'package:flutter/material.dart';
import 'part2_1.dart';
import 'final_back.dart';

int? times = 0;

void main() => runApp(const Step3App());

class Step3App extends StatefulWidget {
  const Step3App({Key? key}) : super(key: key);

  @override
  _Step3AppState createState() => _Step3AppState();
}

class _Step3AppState extends State<Step3App> {
  String? selectedTime;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: const Align(
            alignment: Alignment.center,
            child: Text('步驟三', style: TextStyle(fontSize: 40, color: Colors.white)),
          ),
        ),
        body: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text('                           ', style: TextStyle(fontSize: 20)),
                        const Text(
                          '時間評級',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold),
                        ),
                        const Text('                           ', style: TextStyle(fontSize: 20)),
                        const Text(
                          '每天從事此作業時間',
                          style: TextStyle(fontSize: 30, color: Colors.black),
                        ),
                        const Text('                           ', style: TextStyle(fontSize: 20)),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.black, width: 1.2),
                          ),
                          child: DropdownButton<String>(
                            hint: const Text(' 大約為', textAlign: TextAlign.center),
                            onChanged: (String? newValue) {
                              setState(() {
                                selectedTime = newValue;
                              });
                            },
                            style: const TextStyle(fontSize: 25, color: Colors.black),
                            value: selectedTime,
                            items: <String>[
                              '1小時',
                              '2小時',
                              '3小時',
                              '4小時',
                              '5小時',
                              '6小時',
                              '7小時',
                              '8小時',
                              '9小時',
                              '10小時',
                            ].map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // 下一步按鈕
            Positioned(
              bottom: 30,
              right: 20,
              child: ElevatedButton(
                onPressed: () {
                  if (selectedTime != null) {
                    if (selectedTime == '1小時') {
                      times = 1;
                    } else if (selectedTime == '2小時') {
                      times = 2;
                    } else if (selectedTime == '3小時') {
                      times = 3;
                    } else if (selectedTime == '4小時') {
                      times = 4;
                    } else if (selectedTime == '5小時') {
                      times = 5;
                    } else if (selectedTime == '6小時') {
                      times = 6;
                    } else if (selectedTime == '7小時') {
                      times = 7;
                    } else if (selectedTime == '8小時') {
                      times = 8;
                    } else if (selectedTime == '9小時') {
                      times = 9;
                    } else if (selectedTime == '10小時') {
                      times = 10;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FinalPage()),
                    );

                  }
                },
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
              ),
            ),

            // 上一步按鈕
            Positioned(
              bottom: 30,
              left: 20,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PageOne()),
                  );

                },
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                ),
                child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
