import 'package:flutter/material.dart';
import 'part3.dart';
import 'part2_2.dart';


void main() => runApp(const Myapp());

int storedLowerSum = 0;

class Myapp extends StatefulWidget {
  const Myapp({Key? key}) : super(key: key);

  @override
  _MyappState createState() => _MyappState();
}

class _MyappState extends State<Myapp> {
  int? lower1;
  int? lower2;
  int? lower3;
  int? lower4;
  int? lower5;
  int? lower6;
  int? lower7;
  int? lower8;
  int? lower9;
  int? lower10;
  int? lower11;
  int? lower12;
  int? lower13;

  int? lowerSum;
  //int? storedLowerSum;
  int? groupValue1;
  int? groupValue2;
  List<int> groupValue3 = [];
  List<int> selectedValues = [];

  @override
  void initState() {
    super.initState();
    groupValue1 = null;
    groupValue2 = null;
    groupValue3 = List<int>.filled(7, 0);// 將 groupValue 設置為 null
  }

  void calculateTotalSum() {
    selectedValues.clear();
    for (int i = 0; i < groupValue3.length; i++) {
      if (groupValue3[i] == 1 || groupValue3[i] == 2) {
        // 如果值是1（或2），則將對應的值添加到 selectedValues 列表中
        selectedValues.add(groupValue3[i]); // +1 是因為索引是從0開始的，而您的值是1、2、3...
      }
    }

    // 使用 selectedValues 進行進一步的運算，例如計算總和
    int sum = selectedValues.fold(0, (acc, value) => acc + value);
    lowerSum = (groupValue2 ?? 0) + (groupValue1 ?? 0) + (sum ?? 0);

    //將總和儲存到storedBackSum變數中
    storedLowerSum = lowerSum??0;
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟二(3/3)',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 42),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              const Text(
                '不良工作條件-下肢',
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('每天從事此作業時間佔比',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '<25%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<int>(
                  value: 10,
                  groupValue: groupValue1,
                  onChanged: (value) {
                    setState(() {
                      groupValue1 = value;
                      lower1 = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text(
                  '25-49%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<int>(
                  value: 20,
                  groupValue: groupValue1,
                  onChanged: (value) {
                    setState(() {
                      groupValue1 = value;
                      lower2 = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text(
                  '51-75%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<int>(
                  value: 30,
                  groupValue: groupValue1,
                  onChanged: (value) {
                    setState(() {
                      groupValue1 = value;
                      lower3 = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text(
                  '>75%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<int>(
                  value: 40,
                  groupValue: groupValue1,
                  onChanged: (value) {
                    setState(() {
                      groupValue1 = value;
                      lower4 = value;
                    });
                  },
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('軀幹扭轉/測傾',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '偶爾',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<int>(
                  value: 1,
                  groupValue: groupValue2,
                  onChanged: (value) {
                    setState(() {
                      groupValue2 = value;
                      lower5 = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text(
                  '經常',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<int>(
                  value: 2,
                  groupValue: groupValue2,
                  onChanged: (value) {
                    setState(() {
                      groupValue2 = value;
                      lower6 = value;
                    });
                  },
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('頭部後傾/嚴重地前傾/\n維持轉頭姿勢',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              CheckboxListTile(
                title: const Text(
                  '偶爾或經常',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                controlAffinity: ListTileControlAffinity.leading, // 控制 Checkbox 的位置
                value: groupValue3[0] == 1,
                onChanged: (value) {
                  setState(() {
                    groupValue3[0] = groupValue3[0] == 1 ? 0 : 1;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text(
                  '軀幹前傾時沒有支撐',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                controlAffinity: ListTileControlAffinity.leading, // 控制 Checkbox 的位置
                value: groupValue3[1] == 2, // 將這裡的比較值更改為2
                onChanged: (value) {
                  setState(() {
                    groupValue3[1] = groupValue3[1] == 2 ? 0 : 2;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text(
                  '經常處在狹窄空間',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                controlAffinity: ListTileControlAffinity.leading, // 控制 Checkbox 的位置
                value: groupValue3[2] == 2,
                onChanged: (value) {
                  setState(() {
                    groupValue3[2] = groupValue3[2] == 2 ? 0 : 2;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text(
                  '不穩定、不平整地板',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                controlAffinity: ListTileControlAffinity.leading, // 控制 Checkbox 的位置
                value: groupValue3[3] == 1,
                onChanged: (value) {
                  setState(() {
                    groupValue3[3] = groupValue3[3] == 1 ? 0 : 1;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text(
                  '潮濕、冷、極乾、衣服淋濕',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                controlAffinity: ListTileControlAffinity.leading, // 控制 Checkbox 的位置
                value: groupValue3[4] == 1,
                onChanged: (value) {
                  setState(() {
                    groupValue3[4] = groupValue3[4] == 1 ? 0 : 1;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text(
                  '強烈震動',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                controlAffinity: ListTileControlAffinity.leading, // 控制 Checkbox 的位置
                value: groupValue3[5] == 1,
                onChanged: (value) {
                  setState(() {
                    groupValue3[5] = groupValue3[5] == 1 ? 0 : 1;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text(
                  '需極度心理專注',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                controlAffinity: ListTileControlAffinity.leading, // 控制 Checkbox 的位置
                value: groupValue3[6] == 1,
                onChanged: (value) {
                  setState(() {
                    groupValue3[6] = groupValue3[6] == 1 ? 0 : 1;
                  });
                },
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push( // 點擊按鈕時導航到第二個畫面
                      context,
                      MaterialPageRoute(builder: (context) => PageTwo()),
                    );
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {
                    calculateTotalSum();  //計算總合並儲存到 storedLowerSum
                    Navigator.push( // 點擊按鈕時導航到第二個畫面
                      context,
                      MaterialPageRoute(builder: (context) => Step3App()),
                    );
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
