import 'package:flutter/material.dart';
import 'part1_3_3.dart';
//intvalue2是上肢變數

String abp='picture/abp2.png';
int intValue2  = 0;

class aftercamera3_2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: YourWidget(),
    );
  }
}

class YourWidget extends StatefulWidget {
  @override
  _YourWidgetState createState() => _YourWidgetState();
}

class _YourWidgetState extends State<YourWidget> {

  String selectedUpperRating = '01';

  List<String> upperOptions = ['01', '02', '03'];

  //int intvalue2=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '步驟一(3/3)',
          style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 10),
            Container(
              width: double.infinity,
              color: Color(0xFFFFDCB2),
              padding: EdgeInsets.symmetric(vertical: 25),
              child: Text(
                '請根據下圖的姿勢評級表選擇合適的姿勢評級',
                style: TextStyle(color: Colors.black, fontSize: 19),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 20),
            Image.asset(
              'picture/abp2.png',
              width: 370,
              height: 375,
            ),
            SizedBox(height: 20),

            buildDropdown('上肢負荷', selectedUpperRating, upperOptions, (String? value) {
              setState(() {
                selectedUpperRating = value!;
              });
            }),
            SizedBox(height: 50),
            ElevatedButton(
              onPressed: () {
                Navigator.push( // 點擊按鈕時導航到第二個畫面
                  context,
                  MaterialPageRoute(builder: (context) => aftercamera3_3()),
                );
              },
              style: ButtonStyle(
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                minimumSize: MaterialStateProperty.all<Size>(Size(170, 50)),
              ),
              child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
            ),
            SizedBox(height: 5),
          ],
        ),
      ),
    );
  }

  Widget buildDropdown(String label, String value, List<String> options, void Function(String?)? onChanged) {
    //int intValue2 =int.tryParse(value) ?? 0;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          '$label:',
          style: TextStyle(fontSize: 20),
        ),
        SizedBox(width: 10),
        DropdownButton<String>(
          value: value,
          items: options.map((rating) {
            return DropdownMenuItem<String>(
              value: rating,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.black,
                    width: 1.2,
                  ),
                ),
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  rating,
                  style: TextStyle(color: Colors.black, fontSize: 20),
                ),
              ),
            );
          }).toList(),
          onChanged:(upvalue){
            intValue2 = int.tryParse(upvalue ?? '0') ?? 0; // 更新整数值
            if (upvalue == '01') {
               int newVariable = 1;
               print('新的整数变量值: $newVariable');
            } else if (upvalue == '02') {
               int newVariable = 2;
               print('新的整数变量值: $newVariable');
            } else if (upvalue == '03') {
               int newVariable = 3;
               print('新的整数变量值: $newVariable');
            } else if (upvalue == '04') {
               int newVariable = 4;
               print('新的整数变量值: $newVariable');
            } else if (upvalue == '05') {
               int newVariable = 5;
               print('新的整数变量值: $newVariable');
            }
               onChanged?.call(upvalue);
            },
        )
      ],
    );
  }
}
