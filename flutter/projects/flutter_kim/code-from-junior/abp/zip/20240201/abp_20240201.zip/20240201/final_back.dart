import 'package:flutter/material.dart';
import 'final_upper.dart';
import 'part3.dart';
import 'part1_3.dart';
import 'part1_3_2.dart';
import 'part1_3_3.dart';
import 'part2_1.dart';

int back = intValue;
int upper = intValue2;
int lower = intValue3;

void main() => runApp(FinalPage());

class FinalPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //測試文本
    String physiologicalText ;   //身體超負荷內文
    String healthConcernText ;   //健康疑慮內文
    String preventiveMeasuresText ;    //採取措施內文
    String circleText = '低風險';   //圓圈內文
    int num = (storedBackSum + back) * (times ?? 0);   //圓圈數字

    //測試圓圈顏色
    Color boxColor;
    if (num < 20) {
      boxColor = Color.fromRGBO(0, 255, 0, 1.0);
    } else if (num >= 20 && num < 50) {
      boxColor = Color.fromRGBO(128, 255, 0, 1.0);
    } else if (num >= 50 && num < 100) {
      boxColor = Color.fromRGBO(245, 245, 0, 1.0);
    } else {
      boxColor = Color.fromRGBO(255, 0, 0, 1.0);
    }

    if (num < 20) {
      circleText = "低風險";
      physiologicalText = "生理過載可能性低";
      healthConcernText = "無預期健康疑慮";
      preventiveMeasuresText = "無";
    } else if (num >= 20 && num < 50) {
      circleText = "中風險";
      physiologicalText = "對恢復能力較弱者有生理過載可能性";
      healthConcernText = "疲勞、低度適應不良問題，可由休息時間做調適";
      preventiveMeasuresText = "針對恢復能力較弱者進行工作再設計，以及其他預防措施";
    } else if (num >= 50 && num < 100) {
      circleText = "高風險";
      physiologicalText = "對一般族群有生理過載可能性";
      healthConcernText = "出現異常(如疼痛)，可能有功能障礙，大部分個案為可逆的，沒有型態學上的表現";
      preventiveMeasuresText = "建議進行工作再設計，以及其他預防措施";
    } else {
      circleText = "超高風險";
      physiologicalText = "生理過載極可能發生";
      healthConcernText = "產生更明確的異常或功能障礙，身體結構上受損，有病態表現";
      preventiveMeasuresText = "需要進行工作再設計，以及其他預防措施";
    }

    return MaterialApp(
      title: 'FinalPage',
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          flexibleSpace: Container(color: Colors.blue,),
          title: const Center(
            child: Text('背的結果報告',
              style: TextStyle(fontSize: 40, color: Colors.white),
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              SizedBox(height: 20),
              Container(
                height: 150,
                child: Center(
                  child: Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: boxColor,
                        width: 13,
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            num.toString(),
                            style: TextStyle(
                              fontSize: 28,
                              color: boxColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            circleText,
                            style: TextStyle(
                              fontSize: 28,
                              color: boxColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Container(
                height: 150,
                child: Center(
                  child: Container(
                    width: 350,
                    height: 120,
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(144, 238, 144, 1.0),
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Center(
                      child: Column(
                        children: [
                          const Text(
                            '身體超負荷:',
                            style: TextStyle(fontSize: 25),
                          ),
                          Text(
                            physiologicalText,
                            style: const TextStyle(fontSize: 20, color: Colors.black),
                            textAlign: TextAlign.start,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                height: 150,
                child: Center(
                  child: Container(
                    width: 350,
                    height: 140,
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(144, 238, 144, 1.0),
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Center(
                      child: Column(
                        children: [
                          const Text(
                            '健康疑慮:',
                            style: TextStyle(fontSize: 25),
                          ),
                          Text(
                            healthConcernText,
                            style: const TextStyle(fontSize: 20, color: Colors.black),
                            textAlign: TextAlign.start,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Container(
                height: 150,
                child: Center(
                  child: Container(
                    width: 350,
                    height: 130,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(144, 238, 144, 1.0),
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Center(
                      child: Column(
                        children: [
                          const Text(
                            '採取措施:',
                            style: TextStyle(fontSize: 25),
                          ),
                          Text(
                            preventiveMeasuresText,
                            style: const TextStyle(fontSize: 20, color: Colors.black),
                            textAlign: TextAlign.start,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.only(bottom: 10 , top: 20), // 調整底部距離為 50
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => Step3App()),
                        );
                      },
                      style: ButtonStyle(
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                        backgroundColor: MaterialStateProperty.all(Colors.blue),
                        minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                      ),
                      child: const Text(
                        '上一頁',
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 13),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => FinalPage2()),
                        );
                      },
                      style: ButtonStyle(
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                        backgroundColor: MaterialStateProperty.all(Colors.blue),
                        minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                      ),
                      child: const Text(
                        '下一頁',
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
