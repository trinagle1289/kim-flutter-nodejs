import 'package:flutter/material.dart';

void main() {
  runApp(Final_lower());
}

class Final_lower extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    String physiologicalText = "生理過載可能性文本";
    String healthConcernText = "健康疑慮文本";
    String preventiveMeasuresText = "預防措施文本";

    return MaterialApp(
      title: 'FinalPage',
      home: Scaffold(
        appBar: AppBar(
          title: const Center(
            child: Text('結果報告',
              style: TextStyle(fontSize: 40),
            ),
          ),
        ),
        body: ListView(
          children: <Widget>[

            Container(
              height: 100,
              child: Center(
                child: Container(
                  width: 350,
                  height: 55,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(40),
                  ),
                  child: const Center(
                    child: Text(
                      '風險等級:',
                      style: TextStyle(fontSize: 38, color: Colors.black),
                    ),
                  ),
                ),
              ),
            ),


            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    width: 160,
                    height: 200,
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(35, 184, 177, 1.0),
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            '生理過載可能性',
                            style: TextStyle(fontSize: 20, color: Colors.black),
                          ),
                          Text(
                            physiologicalText,
                            style: const TextStyle(fontSize: 18, color: Colors.black),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    width: 160,
                    height: 200,
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(35, 184, 177, 1.0),
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            '健康疑慮',
                            style: TextStyle(fontSize: 20, color: Colors.black),
                          ),
                          Text(
                            healthConcernText,
                            style: const TextStyle(fontSize: 18, color: Colors.black),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Container(
              height: 230,
              child: Center(
                child: Container(
                  width: 350,
                  height: 175,
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: BorderRadius.circular(40),
                  ),
                  child: Center(
                    child: Column(
                      children: [
                        const Text(
                          '採取措施:',
                          style: TextStyle(fontSize: 25),
                        ),
                        Text(
                          preventiveMeasuresText,
                          style: const TextStyle(fontSize: 20, color: Colors.black),
                          textAlign: TextAlign.start,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // 儲存資料和結束報告按鈕
            Padding(
              padding: const EdgeInsets.only(bottom: 50, top: 80), // 調整底部距離為 50
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: null,
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                    ),
                    child: const Text(
                      '儲存資料',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 13),
                  ElevatedButton(
                    onPressed: null,
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                    ),
                    child: const Text(
                      '結束報告',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
