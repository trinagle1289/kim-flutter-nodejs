import 'package:flutter/material.dart';

void main() => runApp(const Part2_1());

class Part2_1 extends StatelessWidget {
  const Part2_1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟二(1/3)',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 42),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              const Text(
                '不良工作條件-背部',
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('每天從事此作業時間佔比',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '<25%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '<25%',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '25-49%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '25-49%',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '51-75%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '51-75%',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '>75%',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '>75%',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('軀幹扭轉/測傾',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '偶爾',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '偶爾',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '經常',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '經常',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('頭部後傾/嚴重地前傾/\n維持轉頭姿勢',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '偶爾或經常',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '偶爾或經常',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '軀幹前傾時沒有支撐',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '軀幹前傾時沒有支撐',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '經常處在狹窄空間',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '經常處在狹窄空間',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '不穩定、不平整地板',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '不穩定、不平整地板',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '潮濕、冷、極乾、衣服淋濕',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '潮濕、冷、極乾、衣服淋濕',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '強烈震動',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '強烈震動',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '需極度心理專注',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '需極度心理專注',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
