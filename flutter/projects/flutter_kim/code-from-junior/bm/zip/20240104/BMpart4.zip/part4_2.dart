import 'package:flutter/material.dart';

void main() => runApp(const Part4_2());

class Part4_2 extends StatelessWidget {
  const Part4_2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟四(2/2)',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 42),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                '身體活動: 人力交通工具',
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 30),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('路況不良工作條件',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '路況受限',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '路況受限',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              Transform.translate(
                offset: Offset(-20.0, -10.0),
                child: const Text(
                  '(泥土、粗糙砂石、坑洞、\n黏重土壤、短暫上升坡道)',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 20.0),
                ),
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0),
                  child: Text('氣候條件\n氣候劇烈變化 (e.g 熱、風、雪))',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              ListTile(
                title: const Text(
                  '稀少、偶爾',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '稀少、偶爾',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '經常、頻繁',
                  style: TextStyle(
                    fontSize: 23,
                  ),
                ),
                leading: Radio<String>(
                  value: '經常、頻繁',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
