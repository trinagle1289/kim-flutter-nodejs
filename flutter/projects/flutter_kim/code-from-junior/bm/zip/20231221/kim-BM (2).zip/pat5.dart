import 'package:flutter/material.dart';

void main() {
  runApp(Part5());
}

class Part5 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '步驟五',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: RadioButtonPage(),
    );
  }
}

class RadioButtonPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text(
            ' 步驟五 ',
            style: TextStyle(
              fontSize: 42,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const Text(
              '                ',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            const Align(
              alignment: Alignment.center,
              child: Text(
                '工作協調/時間分布',
                style: TextStyle(
                  fontSize: 42,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const Text(
              '                ',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            ListTile(
              title: const Text(
                '良好',
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
              subtitle: const Text(
                '負荷由於其他活動而頻繁變化\n包含多種工作型態，無在一天內集中進行單一種高強度工作負荷',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              leading: Radio<String>(
                value: '良好',
                groupValue: null,
                onChanged: null,
              ),
            ),
            ListTile(
              title: const Text(
                '受限',
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
              subtitle: const Text(
                '負荷鮮少其他活動而變化\n偶爾在一天內集中進行單一種高強度工作負荷',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              leading: Radio<String>(
                value: '受限',
                groupValue: null,
                onChanged: null,
              ),
            ),
            ListTile(
              title: const Text(
                '不良',
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
              subtitle: const Text(
                '負荷幾乎沒有因其他活動而變化\n經常在一天內集中進行單一種高強度工作負荷，並常達到負荷峰值',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              leading: Radio<String>(
                value: '不良',
                groupValue: null,
                onChanged: null,
              ),
            ),
            const Expanded(child: SizedBox()),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 0, 5, 25),
                    child: ElevatedButton(
                      onPressed: null,
                      style: ButtonStyle(
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                        backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                        minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                      ),
                      child: const Text(
                        '上一步',
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 3),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(5, 0, 10, 25),
                    child: ElevatedButton(
                      onPressed: null,
                      style: ButtonStyle(
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                        backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                        minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                      ),
                      child: const Text(
                        '下一步',
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
