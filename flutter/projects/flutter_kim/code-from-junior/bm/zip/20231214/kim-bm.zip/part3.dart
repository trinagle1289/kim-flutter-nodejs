import 'package:flutter/material.dart';


void main() => runApp(const Step3App());

class Step3App extends StatelessWidget {
  const Step3App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) =>
      const MaterialApp(title: 'Button App', home: Step3of2Field());
}

class Step3of2Field extends StatefulWidget {
  const Step3of2Field({Key? key}) : super(key: key);

  @override
  State<Step3of2Field> createState() => Step3of2FieldState();
}

class Step3of2FieldState extends State<Step3of2Field> {
  List<bool> isOptionOneSelected = [false, false];
  List<bool> isOptionTwoSelected = [false, false];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text('步驟(2/3)',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 40)),
      ),
      body: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
        const SizedBox(height: 30),
        const Text('身體活動:無活動工具',
            style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        const Text(
          '重物的重心位置',
          style: TextStyle(fontSize: 30),
        ),
        Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          const SizedBox(height: 20),
          buildCircularCheckboxTransport(0, '無負重/<3公斤/重物靠近身體並有揹架/雙肩背包。'),
        ]),
        const SizedBox(height: 5),
        Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          const SizedBox(width: 8),
          buildCircularCheckboxSpace(
              0, '重物靠近身體，但用手搬或單肩負重。')
        ]),
        const SizedBox(height: 5),
        Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          const SizedBox(width: 8),
          buildCircularCheckboxSpace(
              0, '重物遠離身體，用手搬。')
        ]),
      ]),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        child: Padding(
          padding: const EdgeInsets.only(top: 0),
          child:
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0))),
                  backgroundColor: MaterialStateProperty.all(Colors.blue),
                  minimumSize:
                  MaterialStateProperty.all<Size>(const Size(170, 50))),
              child: const Text('上一步',
                  style: TextStyle(fontSize: 30, color: Colors.white)),
            ),
            ElevatedButton(
              onPressed: () {

              },
              style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0)),
                  ),
                  backgroundColor: MaterialStateProperty.all(Colors.blue),
                  minimumSize:
                  MaterialStateProperty.all<Size>(const Size(170, 50))),
              child: const Text('下一步',
                  style: TextStyle(fontSize: 30, color: Colors.white)),
            ),
          ]),
        ),
      ),
    );
  }
  Widget buildCircularCheckboxTransport(int index, String subtitle) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 0),
      child: Center(
        child: ListTile(
          title: Row(children: [
            Checkbox(
                value: isOptionOneSelected[index],
                onChanged: (value) {
                 // updateTransportSelectedIndex(index);
                },
                shape: const CircleBorder(),
                activeColor: Colors.blue),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 4, right: 8),
                child: Text(subtitle,
                    style: const TextStyle(fontSize: 20, color: Colors.black)),
              ),
            ),
            const SizedBox(width: 8),
          ]),
          contentPadding: const EdgeInsets.all(0),
        ),
      ),
    );
  }

  Widget buildCircularCheckboxSpace(int index, String subtitle) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 0),
      child: Center(
        child: ListTile(
          title: Row(children: [
            Checkbox(
              value: isOptionTwoSelected[index],
              onChanged: (value) {
                // updateSpaceSelectedIndex(index);
              },
              shape: const CircleBorder(),
              activeColor: Colors.blue,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 4, right: 8),
                child: Text(subtitle,
                    style: const TextStyle(fontSize: 20, color: Colors.black)),
              ),
            ),
            const SizedBox(width: 8),
          ]),
          contentPadding: const EdgeInsets.all(0),
        ),
      ),
    );
  }
}