import 'package:flutter/material.dart';

void main() => runApp(const Step2App());

class Step2App extends StatelessWidget {
  const Step2App({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: Step2Field());
  }
}

class Step2Field extends StatefulWidget {
  const Step2Field({super.key});

  @override
  Step2FieldState createState() => Step2FieldState();
}

class Step2FieldState extends State<Step2Field> {
  String? selectedOption;

  @override
  Widget build(BuildContext context) {
    var appTitle = const Align(
        alignment: Alignment.center,
        child:
        Text('步驟二', style: TextStyle(fontSize: 40, color: Colors.white)));

    var times1 = const Text('時間評級',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold));
    var times3 = const Text('                           ',
        style: TextStyle(fontSize: 20));
    var times2 = const Text('每天執行時間[分鐘/天]',
        style: TextStyle(fontSize: 30, color: Colors.black));

    var appBody = Stack(
      children: [
        Column(
          children: [
            Expanded(
              child: Align(
                alignment: Alignment.center,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      times3,
                      times1,
                      times3,
                      times2,
                      times3,
                      Container(
                        decoration: BoxDecoration(
                            border:
                            Border.all(color: Colors.black, width: 1.2)),
                        child: DropdownButton<String>(
                            value: selectedOption,
                            hint:
                            const Text(' 大約為', textAlign: TextAlign.center),
                            onChanged: (String? newValue) {
                              setState(() {
                                selectedOption = newValue;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 25, color: Colors.black),
                            items: <String>[
                              '≦1',
                              '>1-5',
                              '>5-10',
                              '>10-20',
                              '>20-30',
                              '>30-45',
                              '>45-60',
                              '>60-100',
                              '>100-150',
                              '>150-210',
                              '>210-270',
                              '>270-360',
                              '>360-480',
                            ].map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                  value: value, child: Text(value));
                            }).toList()),
                      ),
                    ]),
              ),
            ),
          ],
        ),

        // 下一步按鈕
        Positioned(
          bottom: 30,
          right: 20,
          child: ElevatedButton(
              onPressed: () {

                // Navigator.push(context,
                //     MaterialPageRoute(builder: (context) => getLhcApp("4")));
              },
              style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0))),
                  backgroundColor:
                  MaterialStateProperty.all<Color>(Colors.blue),
                  minimumSize:
                  MaterialStateProperty.all<Size>(const Size(170, 50))),
              child: const Text('下一步', style: TextStyle(fontSize: 30))),
        ),

        // 上一步按鈕
        Positioned(
          bottom: 30,
          left: 20,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ButtonStyle(
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0))),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                minimumSize:
                MaterialStateProperty.all<Size>(const Size(170, 50))),
            child: const Text('上一步', style: TextStyle(fontSize: 30)),
          ),
        ),
      ],
    );

    return Scaffold(
        appBar: AppBar(backgroundColor: Colors.blue, title: appTitle),
        body: appBody);
  }
}
