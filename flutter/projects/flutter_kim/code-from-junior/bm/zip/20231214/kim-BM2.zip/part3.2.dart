import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kim-BM',
      initialRoute: '/',
      routes: {
        '/': (context) => const FirstPage(),
      },
    );
  }
}

class FirstPage extends StatefulWidget {
  const FirstPage({Key? key}) : super(key: key);

  @override
  _FirstPageState createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  int selectedOption = -1;

  // 調整字體大小的變數
  double titleFontSize = 40;
  double subtitleFontSize = 30;
  double optionTitleFontSize = 22;
  double optionDescriptionFontSize = 20;
  double additionalTextFontSize = 25;

  // 調整左右邊距的變數
  double horizontalPadding = 10.0;

  // 調整文字向右移動的變數
  double additionalTextPadding = 30.0; // 設置初始值

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text(
          '步驟三(1/2)',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 40, color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 5),
            Align(
              alignment: Alignment.center,
              child: Padding(
                padding: EdgeInsets.only(
                    left: horizontalPadding, right: horizontalPadding),
                child: Text(
                  '身體活動: 無移動工具',
                  style: TextStyle(
                    fontSize: titleFontSize,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.center,
              child: Text(
                '不良工作條件',
                style: TextStyle(
                  fontSize: subtitleFontSize,
                  color: Colors.black,
                ),
              ),
            ),
            const SizedBox(height: 10),

            // 獨立的每個選項的勾選框
            buildCircularCheckbox(0, '受限',
                '活動空間狹窄(e.g.防墜安全帽)/站立面可動或傾斜/沙、石路面'),
            const SizedBox(height: 20),
            buildCircularCheckbox(
                1, '嚴重受損', '活動空間受阻/無攀爬輔助工具/荒野'),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  buildCircularCheckbox(2, '危急',
                      '活動空間嚴重受阻(局限空間or危險地點)/視野受限/無休息平台/登山/呼吸防護設備/泥巴路面'),
                  const SizedBox(height: 10),
                  Padding(
                    padding: EdgeInsets.only(left: additionalTextPadding),
                    child: Text(
                      '氣候條件\n氣候劇烈變化 (e.g. 熱、風、雪)',
                      style: TextStyle(
                        fontSize: additionalTextFontSize,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  // 在 '氣候條件' 文字下方新增兩個新選項
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    // 調整 "稀少、偶爾" 文字向下移動的填充
                    child: buildCircularCheckbox(3, '稀少、偶爾', ''),
                  ),
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    // 調整 "經常、頻繁" 文字向下移動的填充
                    child: buildCircularCheckbox(4, '經常、頻繁', ''),
                  ),

                ],
              ),
            ),
            const SizedBox(height: 250),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(
                        const Size(170, 50)),
                  ),
                  child: const Text(
                    '上一步',
                    style: TextStyle(fontSize: 30, color: Colors.white),
                  ),
                ),
                const SizedBox(width: 13),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/next');
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(
                        const Size(170, 50)),
                  ),
                  child: const Text(
                    '下一步',
                    style: TextStyle(fontSize: 30, color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Widget buildCircularCheckbox(int value, String title, String description) {
    return Column(
      children: [
        ListTile(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                    fontSize: optionTitleFontSize, color: Colors.black),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 1.0),
                child: Text(
                  description,
                  style: TextStyle(fontSize: optionDescriptionFontSize,
                      color: Colors.black), // 修改文字顏色為黑色
                ),
              ),
            ],
          ),
          leading: Radio(
            value: value,
            groupValue: selectedOption,
            onChanged: (newValue) {
              setState(() {
                selectedOption = newValue as int;
              });
            },
            activeColor: Colors.blue,
          ),
        ),
      ],
    );
  }
}
