import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Page1(selectedIndex: -1),
  ));
}
class Page1 extends StatelessWidget {
  final List<String> image = [
    'assets/1.png',
    'assets/2.png',
    'assets/3.png',
    'assets/4.png',
    'assets/5.png',
    'assets/6.png',
    'assets/7.png',
    'assets/8.png',
    'assets/9.png',
    'assets/10.png',
    'assets/11.png',
    'assets/12.png',
  ];

  final List<String> imageDescriptions = [
    '≤二輪推車',
    '≤二輪推車',
    '≤二輪推車',
    '可轉動輪',
    '可轉動輪',
    '定向輪子',
    '定向輪子',
    '定向輪子',
    '行人控制型',
    '行人控制型',
    '橋式起重機',
    '懸掛式起重機',
    ];

  final int selectedIndex;

  Page1({required this.selectedIndex});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Center(
            child: Text('搬運工具及重量',
              style:TextStyle(fontSize: 40),
            ),
          ),
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              itemCount: image.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                  },
                  child: Container(
                    margin: EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      border: selectedIndex == index ? Border.all(color: Colors.blue, width: 3) : null,
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.asset(image[index]),
                        ),
                        Text(
                          imageDescriptions[index],
                          style: TextStyle(
                            fontSize: 20.0,
                          ),
                        ), // 圖片下的文字描述
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 5, 25),
                  child: ElevatedButton(
                    onPressed: null, // 按鈕禁用
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                    ),
                    child: const Text(
                      '上一步',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 3),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(5, 0, 10, 25),
                  child: ElevatedButton(
                    onPressed: null, // 按鈕禁用
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                    ),
                    child: const Text(
                      '下一步',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
