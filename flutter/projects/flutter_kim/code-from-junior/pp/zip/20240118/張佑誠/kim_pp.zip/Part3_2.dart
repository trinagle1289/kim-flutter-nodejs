import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Page2(selectedWeightIndex: -1), // 在Page1中使用selectedWeightIndex
  ));
}

class Page2 extends StatelessWidget {
  final int selectedWeightIndex;
  final List<List<double>> variableTable  = [
    //1   ，2    ，3    ，4    ，5     ，6    ，7    ，8    ，9    ，10    ，11    ，12
    [3.0  , 2.0  , 2.5  , 2.5  , 3.0  , 1.0  , 1.0  , 1.0  , 1.0  , 1.0  , 1.0  , 2.0],
    [5.0  , 3.0  , 4.0  , 3.0  , 4.0  , 3.0  , 3.0  , 5.0  , 1.0  , 1.0  , 1.0  , 2.5],
    [10.0 , 6.0  , 7.0  , 4.0  , 6.0  , 6.0  , 6.0  , 10.0 , 2.0  , 1.5  , 1.5  , 3.5],
    [50.0 , 12.0 , 50.0 , 5.0  , 8.0  , 12.0 , 12.0 , 50.0 , 3.0  , 2.0  , 2.0  , 4.5],
    [100.0, 50.0 , 100.0, 7.0  , 12.0 , 50.0 , 50.0 , 50.0 , 4.0  , 2.5  , 2.5  , 6.0],
    [100.0, 100.0, 100.0, 12.0 , 50.0 , 100.0, 100.0, 100.0, 6.0  , 4.0  , 4.0  , 10.0],
    [100.0, 100.0, 100.0, 50.0 , 100.0, 100.0, 100.0, 100.0, 10.0 , 7.0  , 7.0  , 15.0],
    [100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 15.0 , 10.0 , 10.0 , 50.0],
    [100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 50.0 , 50.0 , 20.0 , 100.0],
    [100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 50.0 , 100.0],
  ];

  final List<String> weightRanges = [
    '≤ 50 (kg)',
    '51~100 (kg)',
    '101~200 (kg)',
    '201~300 (kg)',
    '301~400 (kg)',
    '401~600 (kg)',
    '601~800 (kg)',
    '801~1000 (kg)',
    '1001~1300 (kg)',
    '>1300 (kg)'
  ];

  Page2({required this.selectedWeightIndex});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('重量選擇', style: TextStyle(fontSize: 40)),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: weightRanges.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(
                    weightRanges[index],
                    style: TextStyle(fontSize: 30),
                  ),
                  selected: index == selectedWeightIndex,
                  onTap: () {
                    // 在這裡處理選擇重量範圍的邏輯（可選）
                  },
                );
              },
            ),
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 5, 25),
                  child: ElevatedButton(
                    onPressed: null, // 按鈕禁用
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                    ),
                    child: const Text(
                      '上一步',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 3),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(5, 0, 10, 25),
                  child: ElevatedButton(
                    onPressed: null, // 按鈕禁用
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                      minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
                    ),
                    child: const Text(
                      '下一步',
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
