import 'package:flutter/material.dart';

void main() => runApp(const Part5());

class Part5 extends StatelessWidget {
  const Part5({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Text(
            '步驟五',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 40),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                '不良工作條件',
                style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Text(
                '手 / 手臂的位置與活動',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text(
                  '偶爾達到關節活動範圍極限',
                  style: TextStyle(
                      fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '偶爾達到關節活動範圍極限',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '經常達到關節活動範圍極限',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '經常達到關節活動範圍極限',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '力量傳遞 / 應用受限',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text(
                  '重物不易抓握 / 須更大的握持力量 / 沒有造型的握柄',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '重物不易抓握 / 須更大的握持力量 / 沒有造型的握柄',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '重物幾乎難以抓握 / 滑、軟、尖銳的邊緣 / 無或不適當的握柄',
                  style: TextStyle(
                      fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '重物幾乎難以抓握 / 滑、軟、尖銳的邊緣 / 無或不適當的握柄',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '不良的氣候條件',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text(
                  '冷、熱、震動',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '冷、熱、震動',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '極度冷、熱、震動',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '極度冷、熱、震動',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '受限的空間條件',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text(
                  '高度太低、工作空間<1.5m²、地板有點滑、輕微傾斜<5°、有障礙物',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '高度太低、工作空間<1.5m²、地板有點滑、輕微傾斜<5°、有障礙物',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '活動的空間嚴重受限、地板非常滑、地板不平整、傾斜>5°',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '活動的空間嚴重受限、地板非常滑、地板不平整、傾斜>5°',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '衣服',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text(
                  '由於防護衣物或裝備增加額外身體負荷\n例如防火衣、化學防護衣、厚重呼吸防護具',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '由於防護衣物或裝備增加額外身體負荷\n例如防火衣、化學防護衣、厚重呼吸防護具',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '搬運 / 握持困難',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text(
                  '每次搬運 / 持握持續5-10秒，搬運距離2-5公尺',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '每次搬運 / 持握持續5-10秒，搬運距離2-5公尺',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
              ListTile(
                title: const Text(
                  '每次搬運 / 持握持續>10秒，搬運距離>5公尺',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                leading: Radio<String>(
                  value: '每次搬運 / 持握持續>10秒，搬運距離>5公尺',
                  groupValue: null,
                  onChanged: (_) {}, // 空函數，不進行任何操作
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('上一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    minimumSize: MaterialStateProperty.all<Size>(const Size(170, 50)),
                  ),
                  child: const Text('下一步', style: TextStyle(fontSize: 30, color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
