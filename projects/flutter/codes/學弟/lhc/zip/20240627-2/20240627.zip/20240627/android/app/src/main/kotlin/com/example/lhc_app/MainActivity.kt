package com.example.lhc_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
